# Tugas pertemuan ke-3

## Cara mengerjakan tugas

1. Fork repository ini ke akun github anda
2. Setelah proses fork selesai, lakukan clone pada repository hasil fork tersebut
3. Lihat soal pada [jobsheet 3](http://jaringan.sinaungoding.com/03/jobsheet03.html)
4. Silakan kerjakan dengan menggunakan template project yang telah disiapkan. Projek menggunakan ini, untuk struktur package dan class bisa menggunakan yang di praktikum atau buat baru.
5. **Jangan lupa konfirmasi pengerjaan Anda di [lms](http://lms.jti.polinema.ac.id) dengan menyertakan nama dan nim**
6. **Perhatikan juga due date pengerjaan**
